package edu.iot.common.dao;

import edu.iot.common.model.Avata;

public interface AvataDao extends CrudDao<Avata, String> {

}
