package edu.iot.common.model;

public enum UserLevel {
	NORMAL,
	SIVER,
	GOLD,
	ADMIN
}
