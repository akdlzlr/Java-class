package edu.iot.common.model;

import lombok.Data;

@Data
//@AllArgsConstructor
public class Tour {
	private long		tourId;
	private String		name;
	private String		lgType;
	private String		mdType;
	private String		smType;
	private String		region;
	private String		location;
	private String		address;
}
