package edu.iot.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.iot.common.dao.TourDao;
import edu.iot.common.model.Pagination;
import edu.iot.common.model.Search;
import edu.iot.common.model.Tour;

@Service
public class TourServiceImpl implements TourService {

	@Autowired
	TourDao dao;

	@Override
	public Map<String, Object> getPage(int page) throws Exception {
		Map<String, Object> map = new HashMap<>();

		int total = dao.count();
		Pagination pagination = new Pagination(page, total);
		map.put("pagination", pagination);
		map.put("list", dao.getPage(pagination.getPageMap()));
		return map;
	}

	@Override
	public Tour findById(long tourId) throws Exception {
		return dao.findById(tourId);
	}

	@Override
	public List<Tour> search(Search search) throws Exception {
		return dao.search(search);
	}

}
